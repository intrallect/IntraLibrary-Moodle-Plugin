<?php // $Id: misc.php,v 1.11 2007/02/02 12:19:58 sam_marshall Exp $

// * Miscellaneous settings

// Experimental settings page
$temp = new admin_settingpage('experimental', get_string('experimental', 'admin'));
$temp->add(new admin_setting_configcheckbox('enableajax', get_string('enableajax', 'admin'), get_string('configenableajax', 'admin'), 0));
$temp->add(new admin_setting_configcheckbox('enableglobalsearch', get_string('enableglobalsearch', 'admin'), get_string('configenableglobalsearch', 'admin'), 0));
$temp->add(new admin_setting_configcheckbox('smartpix', get_string('smartpix', 'admin'), get_string('configsmartpix', 'admin'), 0));
$ADMIN->add('misc', $temp);

// XMLDB editor
$ADMIN->add('misc', new admin_externalpage('xmldbeditor', get_string('xmldbeditor'), "$CFG->wwwroot/$CFG->admin/xmldb/"));


// hidden scripts linked from elsewhere
$ADMIN->add('misc', new admin_externalpage('oacleanup', 'Online Assignment Cleanup', $CFG->wwwroot.'/'.$CFG->admin.'/oacleanup.php', 'moodle/site:config', true));
$ADMIN->add('misc', new admin_externalpage('upgradeforumread', 'Upgrade forum', $CFG->wwwroot.'/'.$CFG->admin.'/upgradeforumread.php', 'moodle/site:config', true));
$ADMIN->add('misc', new admin_externalpage('upgradelogs', 'Upgrade logs', $CFG->wwwroot.'/'.$CFG->admin.'/upgradelogs.php', 'moodle/site:config', true));
$ADMIN->add('misc', new admin_externalpage('multilangupgrade', get_string('multilangupgrade', 'admin'), $CFG->wwwroot.'/'.$CFG->admin.'/multilangupgrade.php', 'moodle/site:config', !empty($CFG->filter_multilang_converted)));

// INTRALLECT CONFIG - synergy learning 2008
$temp = new admin_settingpage('intrallect', get_string('name', 'intrallect'));
$temp->add(new admin_setting_configtext('intrallect_url', get_string('url', 'intrallect'), get_string('urldescription', 'intrallect'), 'http://demonstrator.intralibrary.com/'));
$temp->add(new admin_setting_configtext('intrallect_log', get_string('log', 'intrallect'), get_string('logdescription', 'intrallect'), 'log.csv'));
$temp->add(new admin_setting_configtext('intrallect_name', get_string('nameused', 'intrallect'), get_string('namedescription', 'intrallect'), 'Intrallect'));
$temp->add(new admin_setting_configtext('intrallect_collection_names', get_string('collectionnames', 'intrallect'), get_string('collectionnamesdescription', 'intrallect'), ''));
$temp->add(new admin_setting_configtext('intrallect_collection_ids', get_string('collectionids', 'intrallect'), get_string('collectionidsdescription', 'intrallect'), ''));
$temp->add(new admin_setting_configtext('intrallect_token', get_string('token', 'intrallect'), get_string('tokendescription', 'intrallect'), ''));
$temp->add(new admin_setting_configtext('intrallect_records', get_string('records', 'intrallect'), get_string('recordsdescription', 'intrallect'), '10'));

$ADMIN->add('misc', $temp);
?>
