<?php // $Id: resource.php,v 1.6.4.2 2007/04/11 01:03:42 nicolasconnault Exp $ 
      // resource.php - created with Moodle 1.7 beta + (2006101003)

$string['resourcetypeintrallect'] = 'Search for a resource';
$string['findresource'] = 'Search for a resource';
$string['notfound'] = 'The query <strong>\"{QUERY}\"</strong> did not return any results.';
$string['name'] = 'Intrallect';
$string['url'] = 'Repository url';
$string['log'] = 'Log file';
$string['nameused'] = 'Repository name';
$string['urldescription'] = 'Url of the repository';
$string['logdescription'] = 'Location of the log file. Make sure the file is writable to by the php script.';
$string['namedescription'] = 'Name used for the repository';
$string['collectionnames'] = 'Name of target collection';
$string['collectionids'] = 'ID of target collection';
$string['token'] = 'Authentication token';
$string['collectionnamesdescription'] = 'The collection which is to be the sole target of the search';
$string['collectionidsdescription'] = 'The collection which is to be the sole target of the search';
$string['tokendescription'] = 'Insert an authentication token (see intraLibrary administrator) to search collections that are protected by that authentication token';
$string['records'] = 'Records per page';
$string['recordsdescription'] = 'if the number of records returned is greater than this the results will be displayed on multiple pages';


?>